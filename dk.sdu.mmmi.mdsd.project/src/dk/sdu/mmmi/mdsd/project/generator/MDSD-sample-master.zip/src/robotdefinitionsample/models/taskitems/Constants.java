/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package robotdefinitionsample.models.taskitems;

/**
 *
 * @author stefh
 */
public class Constants {
    //Direction values
    public final static int RIGHT = 0;
    public final static int UP = 270;
    public final static int LEFT = 180;
    public final static int DOWN = 90;
    
    public static enum OR {
        CANCEL, TERMINATE
    }
}
